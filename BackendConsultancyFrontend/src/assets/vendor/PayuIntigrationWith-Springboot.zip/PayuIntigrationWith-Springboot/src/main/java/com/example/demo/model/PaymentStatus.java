package com.example.demo.model;

public enum PaymentStatus {
	Pending,Failed,Success;
}

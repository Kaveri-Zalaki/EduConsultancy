package com.example.demo.model;

public enum PaymentMode {
	NC,DC,CC
}
